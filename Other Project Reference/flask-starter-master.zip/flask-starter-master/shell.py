import os
from flask import *
from starter import *

os.environ["PYTHONINSPECT"] = 'True'
